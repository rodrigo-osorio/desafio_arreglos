#Desafio 1

#visitas = [1000, 800, 250, 300, 500, 2500]

def promedio(array)

    avg_visits = ((array.inject(0) {|sum, visit| sum+=visit})/Float(array.length)).round(1)

end

#puts promedio(visitas)


