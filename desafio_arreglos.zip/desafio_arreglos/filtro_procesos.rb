#Desafio 4

num = ARGV[0]

def data_filter(selected_num)

    data = File.open('./procesos.data').read
    data_ordered = data.split("\n")
    
    data_print = ''
    
    data_ordered.each do |num|

        if num > selected_num 
            data_print += "#{num} \n"
        end
    
    end

    File.write('./procesos_filtrados.data', data_print)

end

data_filter(num)