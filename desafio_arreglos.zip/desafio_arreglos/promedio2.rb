#Desafio 2

# a = [1000, 800, 250, 300, 500, 2500]
# b = [100, 50000, 300, 2500, 3000, 800]

def compara_arrays(array_1, array_2)

    avg_array_1 = (array_1.inject(0) {|sum, num| sum += num})/Float(array_1.length)
    avg_array_2 = (array_2.inject(0) {|sum, num| sum += num})/Float(array_2.length)

    if (avg_array_1 = avg_array_2)
        max_avg = avg_array_1
    elsif avg_array_1 > avg_array_2
        max_avg = avg_array_1
    else
        max_avg = avg_array_2
    end

    return max_avg
end

# puts compara_arrays(a,b)