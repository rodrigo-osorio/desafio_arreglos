#Desafio 3

# pasos= [100, 21, '231as', 2031, 1052000, '213b', 'b123',5000]

def clear_steps(steps)

    filtered_steps = steps.reject {|step| step.class != Integer || step < 200 || step > 100000 }

end

# print clear_steps(pasos)